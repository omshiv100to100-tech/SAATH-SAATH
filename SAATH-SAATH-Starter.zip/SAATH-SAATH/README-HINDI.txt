SAATH-SAATH — शुरुआती चैट ऐप

इस ZIP में:
- index.html: ऐप का पेज
- style.css: डिजाइन
- app.js: लॉगिन का शुरुआती Firebase कोड और लोकल डेमो चैट

मोबाइल में Acode से खोलें:
1. ZIP को Extract/Unzip करें।
2. Acode में SAATH-SAATH फोल्डर खोलें।
3. index.html को Preview में चलाएँ।

Firebase लॉगिन चालू करने के लिए:
1. Firebase Console में SAATH-SAATH प्रोजेक्ट खोलें।
2. Project settings > General > Your apps > SAATH-SAATH Web खोलें।
3. Firebase SDK config में apiKey और appId कॉपी करें।
4. app.js में PASTE_YOUR_API_KEY_HERE और PASTE_YOUR_WEB_APP_ID_HERE की जगह असली मान डालें।
5. Authentication > Sign-in method में Email/Password चालू करें।

ध्यान दें:
- अभी संदेश केवल उसी ब्राउज़र में लोकल डेमो के रूप में दिखते हैं।
- दूसरे यूजर/मोबाइल के बीच असली Real-Time Chat अभी जोड़ी नहीं गई है।
- इसके लिए अगला चरण Cloud Firestore collections, सुरक्षित rules और चैट स्क्रीन को Firebase से जोड़ना है।
- Firebase config सार्वजनिक वेब कॉन्फ़िगरेशन होता है, लेकिन Firestore Security Rules और Authentication सही रखना बहुत जरूरी है।
- इस शुरुआती डेमो को Play Store पर अपलोड करने योग्य अंतिम Android ऐप न समझें।
