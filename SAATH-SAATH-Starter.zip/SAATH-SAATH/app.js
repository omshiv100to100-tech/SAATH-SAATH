// SAATH-SAATH starter app
// अगला चरण: नीचे Firebase Console से अपनी Web App config भरें।
import { initializeApp } from "https://www.gstatic.com/firebasejs/10.14.1/firebase-app.js";
import {
  getAuth, createUserWithEmailAndPassword, signInWithEmailAndPassword,
  onAuthStateChanged, signOut
} from "https://www.gstatic.com/firebasejs/10.14.1/firebase-auth.js";

const firebaseConfig = {
  apiKey: "PASTE_YOUR_API_KEY_HERE",
  authDomain: "saath-saath-9704f.firebaseapp.com",
  projectId: "saath-saath-9704f",
  storageBucket: "saath-saath-9704f.firebasestorage.app",
  messagingSenderId: "1077403082508",
  appId: "PASTE_YOUR_WEB_APP_ID_HERE"
};

const $ = (id) => document.getElementById(id);
const loginScreen = $("loginScreen");
const chatScreen = $("chatScreen");
const loginMessage = $("loginMessage");
let auth = null;
let firebaseReady = false;

try {
  if (firebaseConfig.apiKey !== "PASTE_YOUR_API_KEY_HERE" &&
      firebaseConfig.appId !== "PASTE_YOUR_WEB_APP_ID_HERE") {
    const app = initializeApp(firebaseConfig);
    auth = getAuth(app);
    firebaseReady = true;
    onAuthStateChanged(auth, user => {
      loginScreen.classList.toggle("hidden", !!user);
      chatScreen.classList.toggle("hidden", !user);
    });
  } else {
    loginMessage.textContent = "डेमो मोड: Firebase Console से Web App config भरने पर लॉगिन चालू होगा।";
  }
} catch (error) {
  loginMessage.textContent = "Firebase सेटअप में समस्या: " + error.message;
}

$("loginForm").addEventListener("submit", async (event) => {
  event.preventDefault();
  const email = $("email").value.trim();
  const password = $("password").value;
  if (!firebaseReady) {
    loginMessage.textContent = "पहले app.js में Firebase Web App config भरें।";
    return;
  }
  loginMessage.textContent = "कृपया प्रतीक्षा करें...";
  try {
    try {
      await signInWithEmailAndPassword(auth, email, password);
    } catch (err) {
      if (err.code === "auth/user-not-found" || err.code === "auth/invalid-credential") {
        await createUserWithEmailAndPassword(auth, email, password);
      } else {
        throw err;
      }
    }
  } catch (error) {
    loginMessage.textContent = "लॉगिन नहीं हुआ: " + error.message;
  }
});

$("logoutBtn").addEventListener("click", async () => {
  if (auth) await signOut(auth);
  else {
    chatScreen.classList.add("hidden");
    loginScreen.classList.remove("hidden");
  }
});

// यह शुरुआती लोकल डेमो चैट है; अभी दूसरे मोबाइल पर संदेश नहीं जाते।
$("messageForm").addEventListener("submit", (event) => {
  event.preventDefault();
  const input = $("messageInput");
  const value = input.value.trim();
  if (!value) return;
  const bubble = document.createElement("div");
  bubble.className = "bubble mine";
  const message = document.createElement("span");
  message.textContent = value;
  const time = document.createElement("small");
  time.textContent = new Date().toLocaleTimeString("hi-IN", {hour:"2-digit", minute:"2-digit"});
  bubble.append(message, time);
  $("messages").appendChild(bubble);
  $("messages").scrollTop = $("messages").scrollHeight;
  input.value = "";
});
